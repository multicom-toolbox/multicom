perl compare_2nd_model.pl ../dsspcmbi T0388.ss MULTICOM-CLUSTER_TS1 ./output_T0388_ss 
