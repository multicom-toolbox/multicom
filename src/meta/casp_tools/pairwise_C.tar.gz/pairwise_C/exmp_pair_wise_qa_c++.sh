#./pair_wise_qa ./T0388.mlist /data/casp9_prepare/script/T0388_casp8.seq /data/tm_score/TMscore_32 ./pairwise_ranks ./pairwise_temp T0388 ./LOG_pairwise

#./pair_wise_qa ./model_path_list_example /data/casp9_prepare/script/query_seq_example /data/tm_score/TMscore_32 ./pairwise_ranks ./pairwise_temp T0388 ./LOG_pairwise

#./q_score ./T0388.mlist ../T0388_casp8.seq /data/tm_score/TMscore_32 ./pairwise_ranks ./pairwise_temp T0388 ./LOG_pairwise
