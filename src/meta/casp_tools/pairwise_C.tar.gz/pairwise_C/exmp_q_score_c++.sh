
./q_score ./T0388.mlist_filtered ../T0388_casp8.seq /data/tm_score/TMscore_32 ./pairwise_ranks T0388 


#./q_score_0.2 T0429.mlist_filtered ./T0429.seq /data/tm_score/TMscore_32 ./pairwise_ranks T0429 
