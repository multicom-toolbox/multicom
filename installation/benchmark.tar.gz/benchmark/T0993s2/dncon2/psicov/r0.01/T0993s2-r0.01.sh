#!/bin/bash
touch T0993s2-r0.01.running
echo "running T0993s2-r0.01 .."
date
/home/casp13/DNCON2/psicov21/psicov21 -z 8 -o -r 0.01 T0993s2.aln > T0993s2-r0.01.psicov
if [ -s "T0993s2-r0.01.psicov" ]; then
   mv T0993s2-r0.01.running T0993s2-r0.01.done
   echo "T0993s2-r0.01 job done."
   date
   exit
fi
mv T0993s2-r0.01.running T0993s2-r0.01.failed
echo "psicov job T0993s2-r0.01 failed!"
date
