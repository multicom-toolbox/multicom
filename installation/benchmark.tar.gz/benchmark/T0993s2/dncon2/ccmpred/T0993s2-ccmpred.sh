#!/bin/bash
touch ccmpred.running
echo "running ccmpred .."
/home/casp13/DNCON2/CCMpred/bin/ccmpred -t 8 T0993s2.aln T0993s2.ccmpred > ccmpred.log
if [ -s "T0993s2.ccmpred" ]; then
   mv ccmpred.running ccmpred.done
   echo "ccmpred job done."
   exit
fi
echo "ccmpred failed!"
mv ccmpred.running ccmpred.failed
