from modeller import *    # Load standard Modeller classes
from modeller.automodel import *    # Load the automodel class

log.verbose()  #request verbose output
env = environ()  #create a new MODELLER environment to build this model
env.io.atom_files_directory = ['.'] #directories of input atom files

a = automodel(env,
              alnfile  = 'bak_T0967.pir',      # alignment filename
              knowns = ( 'meta_center0.pdb1',  'meta_hs2.pdb1',  'meta_hs1.pdb1',  'meta_novel3.pdb1',  'meta_novel4.pdb1',  'meta_star0.pdb1',  'meta_novel2.pdb1',  'meta_compro1.pdb1',  'meta_center1.pdb1',  'meta_star1.pdb1',  'meta_star2.pdb1',  'meta_muster1.pdb1',  'meta_hhsu1.pdb1',  'meta_hh6.pdb1',  'meta_novel1.pdb1',  'meta_hh2.pdb1',  'meta_hs3.pdb1',  'meta_rapt10.pdb1',  'meta_rapt6.pdb1',  'meta_csiblast3.pdb1'), # codes of the templates
              sequence = 'T0967')   # code of the target
a.starting_model= 1             # index of the first model
a.ending_model  = 8    # index of the last model

a.make()
