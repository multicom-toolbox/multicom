#!/bin/bash
touch T1006-d0.03.running
echo "running T1006-d0.03 .."
date
/home/casp13/DNCON2/psicov21/psicov21 -z 8 -o -d 0.03 -z 8 T1006.aln > T1006-d0.03.psicov
if [ -s "T1006-d0.03.psicov" ]; then
   mv T1006-d0.03.running T1006-d0.03.done
   echo "T1006-d0.03 job done."
   date
   exit
fi
mv T1006-d0.03.running T1006-d0.03.failed
echo "psicov job T1006-d0.03 failed!"
date
