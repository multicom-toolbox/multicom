#!/bin/bash
touch T1006-r0.001.running
echo "running T1006-r0.001 .."
date
/home/casp13/DNCON2/psicov21/psicov21 -z 8 -o -r 0.001 T1006.aln > T1006-r0.001.psicov
if [ -s "T1006-r0.001.psicov" ]; then
   mv T1006-r0.001.running T1006-r0.001.done
   echo "T1006-r0.001 job done."
   date
   exit
fi
mv T1006-r0.001.running T1006-r0.001.failed
echo "psicov job T1006-r0.001 failed!"
date
