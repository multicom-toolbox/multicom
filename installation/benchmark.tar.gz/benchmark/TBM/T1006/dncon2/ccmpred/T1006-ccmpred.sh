#!/bin/bash
touch ccmpred.running
echo "running ccmpred .."
/home/casp13/DNCON2/CCMpred/bin/ccmpred -t 8 T1006.aln T1006.ccmpred > ccmpred.log
if [ -s "T1006.ccmpred" ]; then
   mv ccmpred.running ccmpred.done
   echo "ccmpred job done."
   exit
fi
echo "ccmpred failed!"
mv ccmpred.running ccmpred.failed
